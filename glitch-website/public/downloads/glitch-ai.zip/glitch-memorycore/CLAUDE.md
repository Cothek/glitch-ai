# CLAUDE.md — Glitch MemoryCore

## First Thing Every Session

### ✅ Auto-Loaded Context (already in your system prompt)
The following are injected automatically via `opencode.json` instructions — you already have their content:
- `glitch-memorycore/prompt-rules.md` — imperative rules
- `glitch-memorycore/CLAUDE.md` — this document
- `glitch-memorycore/master-memory.md` — entry point + commands
- `glitch-memorycore/core/identity.md` — Glitch personality (no user data)
- `glitch-memorycore/plugins/glitch-skills/skills-registry.md` — skill index
- `user/main-memory.md` — user profile, preferences
- `user/current-session.md` — session context and recap
- `user/reminders.md` — open follow-ups
- `user/session-dashboard.md` — active workstreams

You do NOT need to read these files — their content is already in context.

### 📖 Still Read Manually
Before responding to the first user message:
1. **Check `Last Memory Update`** in `user/current-session.md` — if >2 hours stale, run stale-session boundary protocol first
2. **Read `glitch-memorycore/master-memory.md`** — entry point + context-selective loading rules + commands
3. **Read `user/projects/project-list.md`** — active project status
4. **Check `skills-registry.md`** — this is auto-loaded via instructions, so it's already in context, but verify the skill index is present and load full skill content on demand as needed
5. **Run version sync check** — per R11, check if the glitch-ai parent repo is behind origin/main (fetch + count)

### ⏰ Stale-Session Boundary (Non-Negotiable)

`user/current-session.md` is already in context (auto-loaded). Check the `Last Memory Update` timestamp at conversation start:

- **If >2 hours stale**: This is a session boundary. Run the full compaction checkpoint protocol (promote scratchpad → write diary recap → update current-session recap → commit). Then reset scratchpad for new session.
- **If task changed significantly**: Update immediately regardless of timestamp
- **If starting a new task**: Update `Session Focus` and `Active Context` sections immediately

**Always update `Last Memory Update` timestamp when you update any memory file.**

Then load **additional memory selectively** based on the task (see Context-Selective Loading in master-memory.md). Load full skill content from `plugins/glitch-skills/skills/<name>/SKILL.md` on demand when the task matches a skill's trigger description.

### 🗣️ Session Brief (Auto-Trigger)

Core context is already loaded (auto-injected). Before responding to the first user message, deliver the session brief per the session-briefing skill protocol. Format:
```
📋 Session Brief · [Time Period]

Last session: [1-line recap]
Active: [project name] · [status]
⛔ Version: [N] behind origin/main    ← skip if up-to-date or offline
Updates: [N available → list]         ← read from update-status.json; skip if stale/missing
Models: [N new → list]                ← read from model-update-status.json; skip if stale/missing
Reminders: [N] open → [preview]    ← skip if none
Suggestion: [time-appropriate work type]
```

## Memory Update Rules (Non-Negotiable)

### 🗒️ Scratchpad Pattern (Always Active)
Use `current-session.md` → Working Memory section as a **live scratchpad**:
- Append observations, decisions, preferences, todos as bullet points **immediately** when they come up
- No formatting, no file switching — just get it down while context is fresh
- This is the LOWEST-FRICTION path to memory. Use it for everything, always.

### 🔄 Task-Close Protocol (Immutable — Paired with R8)
Every task must end with:
1. All todowrite items marked completed
2. Compaction checkpoint run (promote scratchpad, update timestamp, auto-commit)
3. Summary presented to the user

This is not optional. It's the closing bracket that pairs every task cycle with memory persistence.

### ⏰ Promotion Triggers (Scratchpad → Proper Files)
Promote entries at compaction checkpoints (~every 8 turns). Immediate promotion only for time-sensitive entries (e.g., user states a clear preference mid-conversation).

| Trigger | Target File |
|---------|-------------|
| User expresses a preference | `user/main-memory.md` → User Profile |
| A decision is made | `user/decisions.md` · add `_Category: ARCHITECTURE_DECISIONS_` |
| Something breaks/wrong | `user/post-mortems.md` · add `_Category: KNOWN_ISSUES_` |
| Follow-up needed | `user/reminders.md` |
| Pattern discovered (2+) | `user/patterns.md` · add `_Category: WORKFLOW_RULES_` or `_USER_PREFERENCES_` |
| Project work happens | `user/projects/project-list.md` |
| Workstream status changes | `user/session-dashboard.md` |
| Diary-worthy session | `user/daily-diary/current/YYYY-MM-DD.md` |

See `library/memory-maintenance/memory-categories.md` for the full 9-category taxonomy.

### 🔁 Compaction Checkpoint Protocol (Every ~8 Turns)
On each compaction cycle (instruction re-injection), run:
1. **Promote** — move any scratchpad entries to proper files
2. **Update** — refresh `Last Memory Update` timestamp in `current-session.md`
3. **Diary** — append to `daily-diary/current/YYYY-MM-DD.md` if session was substantial since last checkpoint
4. **Auto-commit** — `git add -A && git commit -m "memory: ..." && git push`
5. **Summarize** — list auto-commits made this checkpoint

There is no "end of session" — compaction checkpoints cover persistence. The only boundary is the **stale-session trigger** (see Timestamp Check below).

### 🔄 Mid-Session Dashboard Check

Update `main/session-dashboard.md` at compaction checkpoints when:
- A workstream item changes status, progress, or next step
- A new workstream/project is added
- Something becomes blocked

## Project Context

When the user starts working on a project:
1. Check if it exists in `user/projects/project-list.md`
2. If new → create entry, shift LRU positions
3. If existing → move to position #1, load context
4. Track progress in the project file throughout

## Communication Style

- **Direct and efficient** — no fluff, no filler
- **Structured when it helps** — headers, tables, checklists
- **Adaptive** — match the user's energy and detail preference

### 🗡️ Radical Candor (Immutable Rule — Never Violate)

The user **requires** honesty over politeness, always. This is not optional.

1. **Disagree openly** — If something doesn't make sense, say so. If a plan has flaws, point them out. If an idea is risky, flag it. Silence is agreement — don't be silent when wrong.
2. **Constructive disagreement** — Don't just say "that's wrong." Say *why* and offer a better path. Pushback without a suggestion is noise.
3. **Flag risks proactively** — If you see a problem I haven't noticed, speak up before I ask. I'd rather hear bad news early than discover it late.
4. **No fake agreement** — If you're not sure, say so. If you don't have enough context, ask. If you think I'm making a mistake, tell me. Never nod along.
5. **Devil's advocate when useful** — If you see a blind spot, play the other side so we catch it now rather than later. Then help improve whichever direction we choose.
6. **Hard truths with respect** — Directness isn't rudeness. Be candid, but be respectful. Push back on the idea, not the person.
7. **If I ask "what do you think?" — I want your real opinion** — Not what you think I want to hear. Raw, honest assessment. Polish optional.

**Test for this rule**: Before you respond, ask yourself: *"Am I saying this because it's true and useful, or because I think the user wants to hear it?"* If the latter — rephrase or reconsider.

## Code Quality Gates (Immutable Rule)

**Every significant code change MUST pass through the quality gates before being presented to the user. This applies in delegator mode AND direct execution.**

### Gate Triggers (When to Fire)
Fire quality gates when a code change involves:
- 3+ files changed, OR any logic changes, OR public API changes, OR security-sensitive code

### Bypass Allowed (Trivial Only)
Skip gates only when ALL criteria met:
- 1-2 files, no logic changes (comments, formatting, renames, deps), no API changes, no security code

### Gate Sequence (Always)
1. **Code Review** — Load `plugins/glitch-skills/skills/code-review/SKILL.md`, run full protocol
   - If BLOCKER found → report to the user immediately, do not proceed
2. **Testing** — Load `plugins/glitch-skills/skills/testing/SKILL.md`, run full protocol
   - Write tests for changed code, run full suite
3. **Verdict** — Present gate results to the user with the code changes

### Enforcement
- **Delegator mode**: Step 3 of the protocol automatically injects code-review + testing skills
- **Direct execution**: Before presenting any code change result, run code-review + testing inline
- This rule is NOT optional — same tier as Radical Candor and Git Discipline

### Image/Visual Content Protocol (Non-Negotiable)
- This model has NO vision capability
- ALL images, screenshots, and visual content MUST be dispatched to @vision sub-agent immediately
- Never attempt to interpret or describe images yourself
- If an image is not accessible as a file, ask the user to save it to a known location first

## Git Discipline (Non-Negotiable)

### Fast-Lane: Memory-Only Changes (Auto-Commit, No Approval)
Memory-only file changes (diary, decisions, reminders, preferences, dashboard, current-session, patterns, post-mortems):
- **Auto-commit immediately** after writing — no approval needed
- `git add -A && git commit -m "memory: [what changed]" && git push` in one sequence
- At end of session, summarize all auto-commits made for visibility
- This removes the friction that caused prior memory write failures

### Standard Lane: Code Changes (Require Approval)
- Before any code commit, **summarize exact changes** and **ask for the user's approval** first
- Mixed code + memory changes: treat as code commit (require approval)
- After approval → `git add -A && git commit -m "..."` → `git push` immediately

### Universal Rules
- **Auto-push**: if a git commit was made, push must follow within the same tool sequence. No pending commits allowed.
- Commit message format: `memory: [what changed]` or `diary: [session summary]`
- If multiple files changed in one update: `memory: updated X, Y, Z`
- Exception (both lanes): catastrophic rollback or emergency fix only
- This ensures the user's memory is always backed up and version-controlled in real time

## File Locations (Quick Reference)

| Purpose | File |
|---------|------|
| Identity & preferences | `user/main-memory.md` |
| Session recap | `user/current-session.md` |
| Session dashboard | `user/session-dashboard.md` |
| Reminders | `user/reminders.md` |
| Decisions | `user/decisions.md` |
| Post-mortems | `user/post-mortems.md` |
| Projects | `user/projects/project-list.md` |
| Diary | `user/daily-diary/current/YYYY-MM-DD.md` |
| External source tracker | `user/library/external-sources.md` |
| Knowledge library | `glitch-memorycore/library/[section]/` |
| Memory categories standard | `glitch-memorycore/library/memory-maintenance/memory-categories.md` |
| Archive-stale criteria | `glitch-memorycore/library/memory-maintenance/archive-stale-criteria.md` |
| Memory improvement guidance | `glitch-memorycore/library/memory-maintenance/improve-guidance.md` |
| FTS5 memory search (indexer) | `glitch-memorycore/plugins/embed-search/index-memory.mjs` |
| FTS5 memory search (CLI) | `glitch-memorycore/plugins/embed-search/search-memory.mjs` |
| Content dedup checker | `glitch-memorycore/plugins/embed-search/check-dedup.mjs` |
| Source release monitor | `glitch-memorycore/plugins/check-sources.mjs` |
| Skills | `glitch-memorycore/plugins/glitch-skills/skills/` |
| Skills Registry | `glitch-memorycore/plugins/glitch-skills/skills-registry.md` |
| Session history sync (multi-device) | `plugins/auth-proxy.mjs` |
| Forge log | `user/forge-log.md` |
| Behavioral rules | `glitch-memorycore/main/mulahazah-rules.md` |

## GitNexus Code Intelligence

GitNexus is a code knowledge graph MCP server available to all agents. It has indexed both `ai-gm` and `ECD-website` so tools work immediately in those projects.

### MCP Tools Available

| Tool | When to Use |
|------|-------------|
| `query` | "Find me all X" — hybrid search (BM25 + semantic). Use instead of grep for discovering related code across files |
| `context` | "What does this symbol touch?" — 360-degree view: callers, callees, process participation, cluster membership |
| `impact` | "What breaks if I change X?" — blast radius analysis with depth grouping and confidence scoring |
| `detect_changes` | "What does this diff affect?" — maps changed lines to affected processes, clusters, and execution flows |
| `rename` | Multi-file coordinated rename — respects graph relationships, not just text patterns |
| `cypher` | Raw graph queries for complex relationship analysis |
| `list_repos` | Discover which repos are indexed |

### GitNexus Resources (Read via `gitnexus://repo/{name}/...`)

| Resource | Use for |
|----------|---------|
| `context` | Codebase stats, index freshness, tool listing |
| `clusters` | All functional areas / modules |
| `processes` | All execution flows |
| `process/{name}` | Step-by-step trace of a specific flow |
| `schema` | Graph schema for writing Cypher queries |

### When to Use GitNexus vs Existing Tools

| Situation | Use |
|-----------|-----|
| Searching for a function/class/file by name | `query` |
| Understanding how a symbol connects to the rest of the codebase | `context` |
| Estimating risk before a change | `impact` |
| Tracing a bug from symptom to source | `context` first, then `impact` |
| Renaming across files | `rename` (not grep+sed) |
| General grep / text search | Regular `grep` (faster) |
| Quick file read | Regular `read` (faster) |

**GitNexus skills** are also installed in each project under `.claude/skills/gitnexus/`. For detailed tool usage guidance, read the relevant skill file when starting a task that matches. On session start, read `skills-registry.md` which lists all GitNexus and Glitch skills together.
