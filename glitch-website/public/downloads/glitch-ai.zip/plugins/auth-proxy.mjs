/**
 * Auth Proxy — sits between cloudflare tunnel and opencode web server.
 * Adds Authorization: Basic header to all requests so the browser
 * never sees a 401/native auth prompt on assets or API calls.
 *
 * Usage: node plugins/auth-proxy.mjs [port] [upstream]
 *   Default port: 4101
 *   Default upstream: http://localhost:4102
 */

import http from 'node:http';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const rootDir = resolve(__dirname, '..');
const pwFile = resolve(rootDir, '.server-password');

let password;
try {
  password = readFileSync(pwFile, 'utf-8').trim();
} catch {
  console.error('Error: .server-password not found at', pwFile);
  process.exit(1);
}
const authToken = Buffer.from(`opencode:${password}`).toString('base64');

const PROXY_PORT = parseInt(process.argv[2] || '4101', 10);
const UPSTREAM_URL = process.argv[3] || 'http://localhost:4102';
const upstream = new URL(UPSTREAM_URL);

const server = http.createServer((req, res) => {
  // Strip directory and workspace params from /agent requests
  // (server bug: workspace crashes, directory filters out custom agents)
  let targetPath = req.url;
  if (req.url) {
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname === '/agent') {
        url.searchParams.delete('directory');
        url.searchParams.delete('workspace');
        targetPath = url.pathname + url.search;
        if (targetPath !== req.url) {
          console.log(`  Stripped params from /agent: ${req.url} -> ${targetPath}`);
        }
      }
    } catch {}
  }

  const options = {
    hostname: upstream.hostname,
    port: upstream.port || 80,
    path: targetPath,
    method: req.method,
    headers: {
      ...(Object.fromEntries(
        Object.entries(req.headers)
          .filter(([key]) => !['host', 'authorization'].includes(key.toLowerCase()))
      )),
      host: upstream.host,
      authorization: `Basic ${authToken}`,
    },
  };

  const proxyReq = http.request(options, (proxyRes) => {
    // For API responses, disable caching so sessions always refresh
    if (req.url.startsWith('/api/') || req.url.startsWith('/session/') || req.url.startsWith('/assets/')) {
      proxyRes.headers['cache-control'] = 'no-cache, no-store, must-revalidate';
      proxyRes.headers['pragma'] = 'no-cache';
      proxyRes.headers['expires'] = '0';
    }
    res.writeHead(proxyRes.statusCode, proxyRes.headers);
    proxyRes.pipe(res);
  });

  proxyReq.on('error', (err) => {
    console.error(`Proxy error for ${req.method} ${req.url}:`, err.message);
    if (!res.headersSent) {
      res.writeHead(502, { 'Content-Type': 'text/plain' });
      res.end('Bad Gateway');
    }
  });

  req.pipe(proxyReq);
});

server.listen(PROXY_PORT, () => {
  console.log(`  Auth proxy listening on :${PROXY_PORT} -> ${UPSTREAM_URL}`);
  console.log(`  Password: ${password}`);
});
